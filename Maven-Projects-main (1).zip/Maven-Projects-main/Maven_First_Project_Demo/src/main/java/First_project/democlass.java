package First_project;

public class democlass {
	
	public String demo() {
		return "hello";
	}

}
