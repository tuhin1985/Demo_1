package First_project;

import static org.junit.Assert.*;

import org.junit.Test;

public class demoTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
